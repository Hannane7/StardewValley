package com.untildawn.views.InGameMenus;

import com.badlogic.gdx.Screen;
import com.untildawn.views.AppMenu;


import java.util.Scanner;
import java.util.function.Consumer;

public class HomeMenu implements Screen, AppMenu {
    @Override
    public void handleInput(Scanner sc) {

    }

    @Override
    public void showMessage(String message) {

    }

    @Override
    public void showError(String error) {

    }

    @Override
    public void showMessageAndExecute(String message, Runnable onClose) {

    }

    @Override
    public void showConfirmation(String message, Consumer<Boolean> resultCallback) {

    }


    public String prompt(String message) {
        return "";
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float v) {

    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
