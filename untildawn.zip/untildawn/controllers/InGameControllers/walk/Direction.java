package com.untildawn.controllers.InGameControllers.walk;

public enum Direction {
    UP, DOWN, LEFT, RIGHT, NONE
}
