package com.untildawn.controllers.InGameControllers;

public class HomeMenuController {
    public static void home() {

    }
}
