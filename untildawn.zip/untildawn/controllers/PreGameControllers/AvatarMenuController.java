package com.untildawn.controllers.PreGameControllers;

import com.untildawn.views.PreGameMenus.AvatarMenuView;
import com.untildawn.views.PreGameMenus.GameMenuView;

public class AvatarMenuController {
    private AvatarMenuView view;

    public void setView(AvatarMenuView view) {
        this.view = view;
    }

    public void handleButtons() {

    }
}
