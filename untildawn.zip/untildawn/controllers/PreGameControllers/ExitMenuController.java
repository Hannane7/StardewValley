package com.untildawn.controllers.PreGameControllers;

import com.untildawn.views.PreGameMenus.ExitMenuView;

public class ExitMenuController {
    private ExitMenuView view;
    public void setView(ExitMenuView view) {
        this.view = view;
    }

    public void handleButtons() {

    }
}
