package com.untildawn.models.MessageCenter;

public enum MessageType {
    SUCCESS,
    ERROR,
    WARNING,
    CONFIRMATION,
}
