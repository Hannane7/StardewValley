package com.untildawn.models.MapElements;


public class Lake {
    private Tile[] tile;
    public Lake(Tile[] tile) {
        this.tile = tile;
    }

}
