package com.untildawn.models.MapElements;

public class House {
    private Tile[] area;
}
