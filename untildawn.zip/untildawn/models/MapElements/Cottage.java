package com.untildawn.models.MapElements;

public class Cottage {
    private Tile[] tile;

    public Cottage(Tile[] tile) {
        this.tile = tile;
    }

    public Tile[] getTile() {
        return tile;
    }
}
