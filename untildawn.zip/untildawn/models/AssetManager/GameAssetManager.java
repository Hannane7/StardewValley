package com.untildawn.models.AssetManager;

public interface GameAssetManager {
}
