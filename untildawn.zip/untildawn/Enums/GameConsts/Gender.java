package com.untildawn.Enums.GameConsts;

public enum Gender {
    MALE,
    FEMALE,
    OTHER;
}
