package com.untildawn.Enums.GameMenus;

import java.util.Scanner;

/*
    Interface for all menu enums.
 */
public interface Menu {

}
