package com.untildawn.Enums.ItemConsts;

public interface Level {
}
